"""
Microservicio de Productos — archivo único de entrada.
 
Reemplaza los archivos duplicados api_main.py y productos_api.py.
Ejecutar con:  uvicorn main:app --host 0.0.0.0 --port 8010 --reload
"""
 
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from database import SessionLocal, engine
import models
import schemas
 
models.Base.metadata.create_all(bind=engine)
 
app = FastAPI(title="Microservicio de Productos")
 
# CORS: acepta localhost en cualquier puerto (desarrollo Flutter Web, Vite, etc.)
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"^https?://(localhost|127\.0\.0\.1)(:\d+)?$|^https://.*\.vercel\.app$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
 
 
# ─── Dependencia de base de datos ───────────────────────────────────────────
 
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
 
 
# ─── Helpers ────────────────────────────────────────────────────────────────
 
def _producto_a_detalle(p: models.Producto) -> schemas.ProductoDetalle:
    return schemas.ProductoDetalle(
        id=p.id,
        codigo=p.codigo,
        nombre=p.nombre,
        descripcion=p.descripcion,
        precio_venta=float(p.precio_venta),
        costo=float(p.costo),
        stock=p.stock,
        stock_minimo=p.stock_minimo,
        id_categoria=p.id_categoria,
        id_marca=p.id_marca,
        unidad_medida=p.unidad_medida,
        activo=p.activo,
        fecha_creacion=p.fecha_creacion,
        categoria=p.categoria.nombre if p.categoria else "",
        marca=p.marca.nombre if p.marca else "",
    )
 
 
# ─── Rutas ──────────────────────────────────────────────────────────────────
 
@app.get("/")
def inicio():
    return {"mensaje": "Microservicio de productos funcionando correctamente"}
 
 
@app.get("/productos", response_model=list[schemas.ProductoDetalle])
def listar_productos(db: Session = Depends(get_db)):
    productos = db.query(models.Producto).all()
    return [_producto_a_detalle(p) for p in productos]
 
 
@app.get("/productos/{id}", response_model=schemas.ProductoDetalle)
def obtener_producto(id: int, db: Session = Depends(get_db)):
    p = db.query(models.Producto).filter(models.Producto.id == id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    return _producto_a_detalle(p)
 
 
@app.post("/productos", response_model=schemas.ProductoResponse)
def crear_producto(producto: schemas.ProductoCreate, db: Session = Depends(get_db)):
    if producto.precio_venta < producto.costo:
        raise HTTPException(
            status_code=400,
            detail="El precio de venta no puede ser menor al costo",
        )
 
    nuevo = models.Producto(**producto.model_dump())
    try:
        db.add(nuevo)
        db.commit()
        db.refresh(nuevo)
        return nuevo
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Código duplicado o datos inválidos")
 
 
@app.put("/productos/{id}", response_model=schemas.ProductoResponse)
def actualizar_producto(
    id: int, producto: schemas.ProductoUpdate, db: Session = Depends(get_db)
):
    p = db.query(models.Producto).filter(models.Producto.id == id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
 
    datos = producto.model_dump(exclude_unset=True)
 
    precio_nuevo = datos.get("precio_venta", float(p.precio_venta))
    costo_nuevo = datos.get("costo", float(p.costo))
    if precio_nuevo < costo_nuevo:
        raise HTTPException(
            status_code=400,
            detail="El precio de venta no puede ser menor al costo",
        )
 
    for campo, valor in datos.items():
        setattr(p, campo, valor)
 
    try:
        db.commit()
        db.refresh(p)
        return p
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Error al actualizar el producto")
 
 
@app.delete("/productos/{id}")
def eliminar_producto(id: int, db: Session = Depends(get_db)):
    p = db.query(models.Producto).filter(models.Producto.id == id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    db.delete(p)
    db.commit()
    return {"mensaje": "Producto eliminado correctamente"}
 
 
@app.put("/productos/descontar/{id}")
def descontar_stock(
    id: int, body: schemas.DescontarStockRequest, db: Session = Depends(get_db)
):
    p = db.query(models.Producto).filter(models.Producto.id == id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    if body.cantidad <= 0:
        raise HTTPException(status_code=400, detail="La cantidad debe ser mayor a 0")
    if p.stock < body.cantidad:
        raise HTTPException(status_code=400, detail="Stock insuficiente")
 
    p.stock -= body.cantidad
    db.commit()
    db.refresh(p)
 
    return {
        "mensaje": "Stock actualizado correctamente",
        "id_producto": p.id,
        "stock_actual": p.stock,
    }